#!/bin/bash
#run main script for mirror-static
source /etc/mirror-static/main.sh


