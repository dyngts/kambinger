#!/bin/bash
#run main script for mirror-static located at /etc/mirror-static/
source /etc/mirror-static/main.sh


