kambinger
=========

How to edit config file
-----------------------
[main] --> general configuration
base_url --> your base url
base_path --> your base path


[Page Name] --> folder name or page name
template --> template file in html format
generator --> script file to generate page
list --> list of page's content. See File format below
output --> file name for output

contact --> email or contact information. Will be converted into image
image --> path to contact image


File format for each page list
------------------------------
 
 Home
>[Title];[Content]


 Mirror
>[Name];[Link]


 Alternative
>[Name];[Link];[Info]

 FAQ
>[Question];[Answer]
